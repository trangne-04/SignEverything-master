import traceback

from endesive import exceptions, pdf


def main():
    trusted_cert_pems = [
        # unizeto
        open("nccert2016.crt.pem", "rb").read(),
        # demo ca chain
        open("ca/demo2_ca.root.crt.pem", "rb").read(),
        # demo hsm ca chain
        # open("cert-hsm-ca.pem", "rb").read(),
    ]
    for fname in (
        # "generated/test-PDFXRef-signed-cms.pdf",
        # "generated/test-PDFXRefStream-signed-cms.pdf",
        # "generated/test-SHA256_RSA-signed-cms.pdf",
        # "generated/pdf-acrobat.pdf",
        # "generated/pdf-signed-cms-hsm-certum.pdf",
        # "generated/pdf-signed-cms-hsm.pdf",
        # "pdf-signed-java.pdf",
        # "pdf-signed-pypdf.pdf",
        # "pdf-encrypted-signed-java.pdf",
        # "pdf-encrypted-signed-pypdf.pdf",
        # "pdf-link-signed-java.pdf",
        # "pdf-link-signed-pypdf.pdf",

        "generated/pdf-encrypted-AES-128-signed-cms.pdf",
        "generated/pdf-encrypted-AES-256-R5-signed-cms.pdf",
        "generated/pdf-encrypted-AES-256-signed-cms.pdf",
        "generated/pdf-encrypted-RC4-128-signed-cms.pdf",
        "generated/pdf-encrypted-RC4-40-signed-cms.pdf",
        "generated/pdf-qpdf-signed-cms.pdf",
        "generated/pdf-sign-cms-form-field.pdf",
        "generated/pdf-sign-cms-form-img.pdf",
        "generated/pdf-sign-cms-form-menual.pdf",
        "generated/pdf-sign-cms-form-signature.pdf",
        "generated/pdf-signed-cms.pdf",
        "generated/pdf-signed-cms-hash.pdf",
        "generated/pdf-signed-cms-hsm.pdf",
        "generated/pdf-signed-cms-hsm-signature_appearance.pdf",
        "generated/pdf-signed-cms-hsm-signature_manual.pdf",
        "generated/pdf-signed-cms-ltv.pdf",
        "generated/pdf-signed-cms-m32-unizeto.pdf",
        "generated/pdf-signed-cms-pfx.pdf",
        "generated/pdf-signed-cms-pil.pdf",
        "generated/pdf-signed-cms-twice-1.pdf",
        "generated/pdf-signed-cms-twice-2.pdf",
        "generated/pdf-signed-cms-twice-end.pdf",
        "generated/pdf-signed-fpdf.pdf",
        "generated/pdf-timestamped-cms.pdf",
    ):
        print("*" * 20, fname)
        try:
            data = open(fname, "rb").read()
        except:
            print("skip")
            continue
        try:
            result, more = pdf.verify(data, trusted_cert_pems)
            print("signature ok?", result.signatureok)
            print("hash ok?", result.hashok)
            print("cert ok?", result.certok)
            print(
                "ocsp ok?", result.ocspok, "ocsp data:", result.ocspdata, result.ocspmsg
            )
            print("tsp ok?", result.tspok, "tsp data:", result.tspdata, result.tspmsg)
            print("more?", more)
        except exceptions.TSPVerificationError as exc:
            print('untrusted timestamp:', exc)
        except Exception as exc:
            print(exc)

            traceback.print_exc()


main()
