import datetime

from cryptography.hazmat import backends
from cryptography.hazmat.primitives.serialization import pkcs12

from endesive.pdf import cms

# import logging
# logging.basicConfig(level=logging.DEBUG)


def main():
    #tspurl = "http://time.certum.pl"
    tspurl = "http://public-qlts.certum.pl/qts-17"
    tspurl = None
    date = datetime.datetime.now(datetime.UTC)
    date = date.strftime("D:%Y%m%d%H%M%S+00'00'")
    dct = {
        "aligned": 8192,
        "sigflags": 3,
        "sigflagsft": 132,
        "sigpage": 0,
        # "sigbutton": True,
        # "sigfield": "Signature1",
        # "auto_sigfield": True,
        # "sigandcertify": True,
        # "signaturebox": (470, 840, 570, 640),
        "signature": "Dokument podpisany cyfrowo ąćęłńóśżź",
        # "signature_img": "signature_test.png",
        "contact": "contact:mak@trisoft.com.pl",
        "location": "Szczecin",
        "signingdate": date,
        "reason": "Dokument podpisany cyfrowo aą cć eę lł nń oó sś zż zź",
        "password": "1234",
    }
    with open("ca/demo2_user1.p12", "rb") as fp:
        p12 = pkcs12.load_key_and_certificates(
            fp.read(), b"1234", backends.default_backend()
        )
    for algorithm in ["RC4-40", "RC4-128", "AES-128", "AES-256-R5", "AES-256"]:
        fname = f"generated/pdf-encrypted-{algorithm}.pdf"
        datau = open(fname, "rb").read()
        datas = cms.sign(
            datau,
            dct,
            p12[0], p12[1], p12[2], "sha256",
            None,
            tspurl,
        )
        fname = fname.replace(".pdf", "-signed-cms.pdf")
        with open(fname, "wb") as fp:
            fp.write(datau)
            fp.write(datas)

    fname = f"generated/pdf-qpdf.pdf"
    datau = open(fname, "rb").read()
    datas = cms.sign(
        datau,
        dct,
        p12[0], p12[1], p12[2], "sha256",
        None,
        tspurl,
    )
    fname = fname.replace(".pdf", "-signed-cms.pdf")
    with open(fname, "wb") as fp:
        fp.write(datau)
        fp.write(datas)

main()
